<?php
echo "WEITERLEITUNG TO dashboard/landing_page.php";
header("Location: dashboard/landing_page.php");



?>