<?php
echo "<a href='/smarthome_v2/dashboard/landing_page.php'>Start</a>";
echo "<a href='/smarthome_v2/dashboard/dashboard.php'>Dashboard</a>";
echo "<a href='/smarthome_v2/management/channel_management.php'>Channel Management</a>";
echo "<a href='/smarthome_v2/management/device_management.php'>Device Management</a>";
echo "<a href='/smarthome_v2/management/zone_management.php'>Zone Management</a>";
echo "<a href='/smarthome_v2/management/node_management.php'>Node Management</a>";

echo "<a href='/smarthome_v2/help/log.php'>Activity Log</a>";
?>