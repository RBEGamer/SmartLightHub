<?php
$db_host="localhost"; // Host name 
$db_username="smart_light"; // Mysql username 
$db_password="smart_light"; // Mysql password 
$db_name="smart_light"; // Database name 
?>