<?php
echo "<a href='/smarthome_v2/dashboard/dashboard.php'>Zurueck / Dashboard</a>";
echo "<a href='/smarthome_v2/management/add_zone.php'>Add Zone</a>";
echo "<a href='/smarthome_v2/management/edit_zone.php'>Edit Zone</a>";
echo "<a href='/smarthome_v2/management/delete_zone.php'>Delete Zone</a>";

?>