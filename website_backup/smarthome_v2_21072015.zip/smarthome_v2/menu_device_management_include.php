<?php
//menu_device_management_include.php


echo "<a href='/smarthome_v2/dashboard/dashboard.php'>Zurueck / Dashboard</a>";
echo "<a href='/smarthome_v2/management/add_device.php'>Add Device</a>";
echo "<a href='/smarthome_v2/management/edit_device.php'>Edit Device</a>";
echo "<a href='/smarthome_v2/management/delete_device.php'>Delete Device</a>";


?>